
; This is my patch to add 19.2K serial terminal input and output
; to FIG-FORTH for the 1802. The serial code is too big to put inline
; into the existing EMIT, KEY, QTERM, and CR word definitions. It
; does fit, however, into the 94 bytes that are reserved at the
; beginning of FIG-FORTH for initialization code.
;
; Since FIG-FORTH does not use R6, I have taken that as a subroutine
; pointer to call three routines for I/O. This is done by modifying
; the value of R6 slightly when calling as follows:
; 
;   INC R6  \_ This outputs the character in D
;   SEP R6  /
;
;   GLO R6  \_ This inputs a character into D
;   SEP R6  /
;
;   GHI R6  \_ This checks if break is pressed
;   SEP R6  /
;
; I implemented break as the I key on the Super Elf (EF4 pin).
;
; The new initialization code as well as the patches to overwrite
; EMIT, KEY, QTERM, and CR are below. This requires a 1.79Mhz clock
; as in the Super ELF. You might need to swap the SEQ and REQs and
; change the BN3 instruction depending on the polarity of your
; hardware.
;
; Files included:
; 
;   forth-original.lst     -- the FIG-FORTH code I started with
;   forth-original.bin     -- unmodified binary version of the above
;   forth-serial-19.2k,bin -- binary patched with the code below
;
; If there are any odd typos, this was assembled by hand and my
; syntax check is very forgiving :)
                                        
                                        
0000    71              DIS             
0001    00              BYTE    0       
                                        
0002    90              GHI     R0      
0003    B3              PHI     R3      
0004    B6              PHI     R6      
                                        
0005    F8 0C           LDI     TERMIO  
0007    A6              PLO     R6      
                                        
0008    F8 5E           LDI     START   
000A    A3              PLO     R3      
                                        
000B    D3      RETIO   SEP     R3      
                                        
000C    C8      TERMIO  LSKP            
000D    30 26           BR      OUTPUT  
000F    32 17           BZ      INPUT   
                                        
0011    96      BREAK   GLO     R6      
0012    3F 0B           BN4     RETIO   
0014    86              GHI     R6      
0015    30 0B           BR      RETIO   
                                        
0017    36 17   INPUT   BN3     INPUT   
0019    96              GHI     R6      
001A    96              GHI     R6      
                                        
001B    FF 00   SPACE   SMI     0       
001D    76      MARK    SHRC            
001E    33 0B           BDF     RETIO   
0020    D6              SEP     R6      
0021    D6              SEP     R6      
0022    36 1B           BN3     SPACE   
0024    30 1D           BR      MARK    
                                        
0026    7B      OUTPUT  SEQ             
0027    76              SHRC            
0028    B8              PHI     R8      
                                        
0029    F8 04           LDI     4       
002B    A8              PLO     R8      
002C    33 3D           BDF     REQ1    
                                        
002E    7B      SEQ1    SEQ             
002F    98              GHI     R8      
0030    76              SHRC            
0031    33 42           BDF     REQ2    
                                        
0033    76      SEQ2    SHRC            
0034    B8              PHI     R8      
0035    7B              SEQ             
0036    7B              SEQ             
                                        
0037    28      LOOP    DEC     R8      
0038    88              GLO     R8      
0039    32 47           BZ      STOP    
003B    3B 2E           BNF     SEQ1    
                                        
003D    7A      REQ1    REQ             
003E    98              GHI     R8      
003F    76              SHRC            
0040    3B 33           BNF     SEQ2    
                                        
0042    76      REQ2    SHRC            
0043    B8              PHI     R8      
0044    7A              REQ             
0045    30 37           BR      LOOP    
                                        
0047    7A      STOP    REQ             
0048    30 0B           BR      RETIO   
                                        
                                        
                                        
0565    19              INC     R9      
0566    09              LDN     R9      
0567    29              DEC     R9      
0568    29              DEC     R9      
0569    29              DEC     R9      
056A    FA 7F           ANI     $7F
056C    16              INC     R6      ;OUTPUT
056D    D6              SEP     R6      
056E    DC              SEP     RC      
056F    00                              
0570    00                              
0571    00                              
                                        
                                        
                                        
057E    96              GHI     R6      ;INPUT
057F    D6              SEP     R6      
0580    59              STR     CSTACK  
0581    29              DEC     CSTACK  
0582    96              GHI     R6      
0583    59              STR     CSTACK  
0584    DC              SEP     RC      
0585    00                              
0586    00                              
0587    00                              
0588    00                              
0589    00                              
058A    00                              
                                        
                                        
                                        
059D    86              GLO     R6      ;BREAK
059E    D6              SEP     R6      
059F    73              STXD            
05A0    96              GHI     R6      
05A1    59              STR     CSTACK  
05A2    DC              SEP     RC      
05A3    00                              
05A4    00                              
05A5    00                              
                                        
                                        
                                        
05AD    F8 0D           LDI     $0D     
05AF    16              INC     R6      ;OUTPUT
05B0    D6              SEP     R6      
05B1    F8 0A           LDI     $0A     
05B3    16              INC     R6      ;OUTPUT
05B4    D6              SEP     R6      
05B5    DC              SEP     RC      
05B6    00                              
05B7    00                              
05B8    00                              
05B9    00                              
05BA    00                              
05BB    00                              
05BC    00                              
05BD    00                              
05BE    00                              
05BF    00                              
05C0    00                              
05C1    00                              
